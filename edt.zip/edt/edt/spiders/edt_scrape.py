# -*- coding: utf-8 -*-
import scrapy
from ..items import EdtItem


class EdtScrapeSpider(scrapy.Spider):
    name = 'edt_scrape'
    a_domains = ['https://www.edt-sg.com/en/']
    start_urls = ['https://www.edt-sg.com/en/funds.html']

    def parse(self, response):
        for link in response.xpath('//*[@id="tablaFondos"]/tbody/tr'):
            url = link.xpath('td[1]/a/@href').extract_first()
            fund = link.xpath('td[1]/a/@href').extract_first()
            asset_type = link.xpath('td[2]/a/@href').extract_first()
            amount_issue = link.xpath('td[3]/a/@href').extract_first()
            issue_date = link.xpath('td[4]/a/@href').extract_first()
            follow_link = self.a_domains[0] + url
            print(f'url is {follow_link}')
            yield scrapy.Request(follow_link, callback=self.parse_asset)

    def parse_asset(self,response):#, fund, asset_type, amount_issue, issue_date):
        asset_link = response.xpath('//*[@id="navbar"]/ul/li[2]/a/@href').extract_first()
        liability_link = response.xpath('//*[@id="navbar"]/ul/li[3]/a/@href').extract_first()
        asset_link = self.a_domains[0] + asset_link
        liability_link = self.a_domains[0] + liability_link
        for i in range(1, 2):
            if i == 1:
                print(f'asset link is {asset_link}')
                if asset_link is not None:
                    yield scrapy.Request(asset_link, callback=self.process_asset_libilities)
            elif i == 2:
                if liability_link is not None:
                    yield scrapy.Request(liability_link, callback=self.process_asset_libilities)

    def process_asset_libilities(self, response):
        try:
            item = EdtItem()
            for table in response.xpath('//*[@id="component"]/main/article/div/table'):
                for table_row in table.xpath('tbody/tr'):
                    try:
                        download_link = table_row.xpath('td[1]/a/@href').extract_first()
                        if download_link is not None:
                            if '.PDF' in str(download_link).upper():
                                download_link = "https://www.edt-sg.com" + download_link
                                item['file_urls'] = [download_link]
                                item['files'] = download_link.split('/')[-1]
                                print(f'response link={response.url}  download link ={download_link}')
                                yield item
                    except:
                        pass
        except:
            print("error")
