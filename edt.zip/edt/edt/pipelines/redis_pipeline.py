# -*- coding: utf-8 -*-

# Define your item pipelines here
#
# Don't forget to add your pipeline to the ITEM_PIPELINES setting
# See: https://docs.scrapy.org/en/latest/topics/item-pipeline.html
import redis
from scrapy.exceptions import DropItem


class RedisPipeline(object):
    global conn

    def open_spider(self, spider):
        self.conn = redis.Redis()

    def close_spider(self, spider):
        self.conn.close()

    def process_item(self, item, spider):
        find_data = item['file_urls'][0]
        print(f'find Data is {find_data}')
        if self.conn.dbsize()>0:
            a = self.conn.get(find_data)
            if a is not None:
                print('Item Dropped')
                raise DropItem("Duplicate item found: %r" % item)
            else:
                a = item.get('file_urls',"not found")
                b = item.get('files',"not Found")
                print(f'value is {a[0]} b is {b}')
                self.conn.set(a[0],b)
                return item
        else:
            a = item.get('file_urls', "not found")
            b = item.get('files', "not Found")
            print(f'value if db size is 0 then a={a[0]} b={b}')
            self.conn.set(a[0], b)
            return item

#    def process_item(self, item, spider):
#        return item
